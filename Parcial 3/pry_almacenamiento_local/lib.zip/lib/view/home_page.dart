import 'package:flutter/material.dart';
import '../core/widgets/custom_app_bar.dart';
import '../core/widgets/custom_icon.dart';
import '../core/widgets/custom_card.dart';
import '../core/widgets/custom_text.dart';

class HomePage extends StatelessWidget{
  HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'INICIAR'),
      body: Center(
        child: CustomCard(child:
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIcon(icon: Icons.check_circle, size: 50,),
            SizedBox(height: 20,),
            CustomText(text: 'Bienvenido',
            style: Theme.of(context).textTheme.titleLarge,
            textAlign: TextAlign.center,),

            SizedBox(height: 20,),
            CustomText(text: 'Pin incorrecto',
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,)
          ]
        )
        ),
      ),
    );
  }



}