// lib/view/contact_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/contacto_viewmodel.dart';
import '../core/widgets/custom_app_bar.dart';
import '../core/widgets/custom_text.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_styles.dart';
import '../model/contacto_model.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      context.read<ContactViewModel>().loadContacts();
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<ContactViewModel>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Mostrar SnackBar cuando hay un mensaje
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (viewModel.operationMessage.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              viewModel.operationMessage,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            backgroundColor: viewModel.isSuccess ? Colors.green : Colors.red,
            duration: const Duration(seconds: 3),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            margin: const EdgeInsets.all(10),
            action: SnackBarAction(
              label: 'OK',
              textColor: Colors.white,
              onPressed: () {
                viewModel.clearMessage();
              },
            ),
          ),
        );
        // Limpiar mensaje después de mostrar
        Future.delayed(const Duration(milliseconds: 500), () {
          viewModel.clearMessage();
        });
      }
    });

    return Scaffold(
      appBar: CustomAppBar(
        title: 'Contactos (${viewModel.contactCount})',
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _showSearchDialog(context, viewModel),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => viewModel.loadContacts(),
          ),
        ],
      ),
      body: Column(
        children: [
          // Barra de búsqueda activa
          if (viewModel.searchQuery.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: isDark ? Colors.grey[800] : Colors.grey[200],
              child: Row(
                children: [
                  Expanded(
                    child: CustomText(
                      text: '🔍 Buscando: "${viewModel.searchQuery}" (${viewModel.filteredCount})',
                      style: AppStyles.body,
                    ),
                  ),
                  TextButton(
                    onPressed: viewModel.clearSearch,
                    child: const Text('Limpiar'),
                  ),
                ],
              ),
            ),
          // Lista de contactos
          Expanded(
            child: viewModel.contacts.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.contacts_outlined,
                    size: 80,
                    color: isDark ? Colors.grey[600] : Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  CustomText(
                    text: viewModel.searchQuery.isNotEmpty
                        ? 'No se encontraron resultados'
                        : 'No hay contactos guardados',
                    style: AppStyles.subtitle,
                  ),
                  const SizedBox(height: 8),
                  CustomText(
                    text: viewModel.searchQuery.isNotEmpty
                        ? 'Prueba con otra búsqueda'
                        : 'Presiona el botón + para agregar uno',
                    style: AppStyles.body.copyWith(
                      color: isDark ? Colors.grey[400] : Colors.grey[600],
                    ),
                  ),
                ],
              ),
            )
                : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: viewModel.contacts.length,
              itemBuilder: (context, index) {
                final contact = viewModel.contacts[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  elevation: 2,
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.primary,
                      child: Text(
                        contact.name.isNotEmpty
                            ? contact.name[0].toUpperCase()
                            : '?',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      contact.name,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('📱 ${contact.phone}'),
                        Text('📧 ${contact.email}'),
                      ],
                    ),
                    isThreeLine: true,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.blue),
                          onPressed: () => _showContactDialog(
                            context,
                            viewModel,
                            contact: contact,
                          ),
                          tooltip: 'Editar contacto',
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _showDeleteDialog(
                            context,
                            viewModel,
                            contact,
                          ),
                          tooltip: 'Eliminar contacto',
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showContactDialog(context, viewModel),
        child: const Icon(Icons.add),
        tooltip: 'Agregar contacto',
      ),
    );
  }

  void _showSearchDialog(BuildContext context, ContactViewModel viewModel) {
    String query = viewModel.searchQuery;
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Buscar contacto'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: 'Nombre, teléfono o email',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) => query = value,
                onSubmitted: (value) {
                  viewModel.searchContacts(value);
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 8),
              Text(
                '${viewModel.contactCount} contactos disponibles',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                viewModel.clearSearch();
                Navigator.pop(context);
              },
              child: const Text('Limpiar'),
            ),
            TextButton(
              onPressed: () {
                viewModel.searchContacts(query);
                Navigator.pop(context);
              },
              child: const Text('Buscar'),
            ),
          ],
        );
      },
    );
  }

  void _showContactDialog(
      BuildContext context,
      ContactViewModel viewModel, {
        ContactModel? contact,
      }) {
    final isEditing = contact != null;
    final nameController = TextEditingController(text: contact?.name ?? '');
    final phoneController = TextEditingController(text: contact?.phone ?? '');
    final emailController = TextEditingController(text: contact?.email ?? '');
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(
                isEditing ? Icons.edit : Icons.person_add,
                color: AppColors.primary,
              ),
              const SizedBox(width: 8),
              Text(isEditing ? 'Editar contacto' : 'Nuevo contacto'),
            ],
          ),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nombre *',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'El nombre es obligatorio';
                    }
                    if (value.length < 2) {
                      return 'El nombre debe tener al menos 2 caracteres';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Teléfono *',
                    prefixIcon: Icon(Icons.phone),
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.phone,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'El teléfono es obligatorio';
                    }
                    if (value.length < 7) {
                      return 'Teléfono inválido';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: emailController,
                  decoration: const InputDecoration(
                    labelText: 'Correo *',
                    prefixIcon: Icon(Icons.email),
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'El correo es obligatorio';
                    }
                    if (!value.contains('@') || !value.contains('.')) {
                      return 'Correo inválido';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                viewModel.clearMessage();
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  final newContact = ContactModel(
                    id: isEditing
                        ? contact!.id
                        : DateTime.now().millisecondsSinceEpoch.toString(),
                    name: nameController.text.trim(),
                    phone: phoneController.text.trim(),
                    email: emailController.text.trim(),
                  );

                  bool success;
                  if (isEditing) {
                    success = await viewModel.updateContact(newContact);
                  } else {
                    success = await viewModel.addContact(newContact);
                  }

                  if (success) {
                    Navigator.pop(context);
                    // El SnackBar se mostrará automáticamente por el listener
                  }
                }
              },
              child: Text(isEditing ? 'Actualizar' : 'Agregar'),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteDialog(
      BuildContext context,
      ContactViewModel viewModel,
      ContactModel contact,
      ) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Eliminar contacto'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('¿Estás seguro de eliminar este contacto?'),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('👤 ${contact.name}',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('📱 ${contact.phone}'),
                    Text('📧 ${contact.email}'),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                viewModel.clearMessage();
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final success = await viewModel.deleteContact(contact.id);
                if (success) {
                  Navigator.pop(context);
                  // El SnackBar se mostrará automáticamente
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Eliminar'),
            ),
          ],
        );
      },
    );
  }
}