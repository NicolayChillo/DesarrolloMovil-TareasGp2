// lib/view/main_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pin_page.dart';
import 'contacto_page.dart';
import '../viewmodel/theme_viewmodel.dart';
import '../viewmodel/pin_viewmodel.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = const [
    PinPage(),
    ContactPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final themeViewModel = context.watch<ThemeViewModel>();
    final pinViewModel = context.watch<PinViewModel>();

    // Escuchar mensajes del PIN
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (pinViewModel.mensaje.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              pinViewModel.mensaje,
              style: const TextStyle(fontSize: 14),
            ),
            backgroundColor: pinViewModel.esCorrecto ? Colors.green : Colors.orange,
            duration: const Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            margin: const EdgeInsets.all(10),
          ),
        );
      }
    });

    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.lock),
            label: 'PIN',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.contacts),
            label: 'Contactos',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          themeViewModel.toggleTheme();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                themeViewModel.isDarkMode
                    ? '🌙 Modo oscuro activado'
                    : '☀️ Modo claro activado',
              ),
              duration: const Duration(seconds: 1),
              behavior: SnackBarBehavior.floating,
            ),
          );
        },
        child: Icon(
          themeViewModel.isDarkMode ? Icons.light_mode : Icons.dark_mode,
        ),
        tooltip: 'Cambiar tema',
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endTop,
    );
  }
}